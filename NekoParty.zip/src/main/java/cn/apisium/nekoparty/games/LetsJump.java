package cn.apisium.nekoparty.games;

import cn.apisium.nekoparty.Knockout;
import cn.apisium.nekoparty.Utils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashSet;
import java.util.Random;

public final class LetsJump extends Game {
    private final static Random random = new Random();
    private boolean[][] grids = new boolean[12][12];
    private final int minX, minZ, maxX, maxZ, maxY, minY, rightX;
    private final Location leftSide;
    private final HashSet<Block> removedBlocks = new HashSet<>();
    private BukkitTask task;
    public LetsJump(Block block, Knockout knockout) {
        super(block, knockout);
        leftSide = block.getLocation().add(-4, 1, 12);
        int tmp = block.getX();
        minX = tmp - 6;
        minZ = block.getZ();
        maxX = tmp + 30;
        maxZ = minZ + 24;
        maxY = block.getY() + 20;
        minY = block.getY() - 20;
        rightX = tmp + 25;
    }

    @Override
    public void init() {
        final Location loc = center.getLocation();
        grids = new boolean[12][12];
        boolean left = false, right = false;
        int prev = 4 + random.nextInt(6);
        for (int i = 0; i < 12;) {
            grids[i][prev] = true;
            boolean canLeft = !right && prev > 0, canRight = !left && prev < 11;
            random.nextBoolean();
            if ((canLeft || canRight) && random.nextBoolean()) {
                if (canLeft && canRight) {
                    if (random.nextBoolean()) {
                        left = true;
                        prev -= 1;
                    } else {
                        right = true;
                        prev += 1;
                    }
                } else prev += canLeft ? -1 : 1;
                grids[i][prev] = true;
            } else {
                left = right = false;
                i++;
            }
        }
        for (int i = 0; i < 12; i++) for (int j = 0; j < 12; j++) loc.clone().add(i * 2, 0, j * 2)
                .getBlock().setType(Material.IRON_BLOCK);

        Location loc2 = loc.clone().add(-2, 0, 0);
        for (int i = 0; i < 5; i++) for (int j = 0; j < 24; j++) loc2.clone().add(-i, 0, j).getBlock().setType(Material.LIGHT_BLUE_CONCRETE);
        loc2 = loc.clone().add(24, 0, 0);
        for (int i = 0; i < 5; i++) for (int j = 0; j < 24; j++) loc2.clone().add(i, 0, j).getBlock().setType(Material.PINK_CONCRETE);
    }

    @Override
    public void clear() {
        final Location loc = center.getLocation();
        for (int i = 0; i < 12; i++) for (int j = 0; j < 12; j++) loc.clone().add(i * 2, 0, j * 2)
                .getBlock().setType(Material.AIR);
        Location loc2 = loc.clone().add(-2, 0, 0);
        for (int i = 0; i < 5; i++) for (int j = 0; j < 24; j++) loc2.clone().add(-i, 0, j).getBlock().setType(Material.AIR);
        loc2 = loc.clone().add(24, 0, 0);
        for (int i = 0; i < 5; i++) for (int j = 0; j < 24; j++) loc2.clone().add(i, 0, j).getBlock().setType(Material.AIR);
    }

    @Override
    public void start() {
        super.start();
        task = Utils.timer(20 * 20, $ -> {
            removedBlocks.forEach(it -> it.setType(Material.IRON_BLOCK));
            removedBlocks.clear();
        });
    }

    @Override
    public void stop() {
        super.stop();
        task.cancel();
    }

    @Override
    public void sendIntroduction() {

    }

    @Override
    public void teleport() {

    }

    @EventHandler
    public void onPlayerToggleSprint(final PlayerToggleSprintEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerMove(final PlayerMoveEvent e) {
        final Location loc = e.getFrom().add(0, -1, 0);
        if (world != loc.getWorld() || loc.getY() < minY || loc.getY() > maxY || loc.getX() < minX ||
                loc.getX() > maxX || loc.getZ() < minZ || loc.getZ() > maxZ) {
            e.getPlayer().teleport(leftSide);
            return;
        }
        if (loc.getX() > rightX) {
            System.out.println(2333);
            return;
        }
        final Block block = loc.getBlock();
        if (block.getType() != Material.IRON_BLOCK || removedBlocks.contains(block)) return;
        final Location loc2 = loc.subtract(center.getLocation());
        if (!grids[loc2.getBlockX() / 2][loc2.getBlockZ() / 2]) {
            removedBlocks.add(block);
            block.setType(Material.AIR);
        }
    }
}
