package cn.apisium.nekoparty;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public final class Constants {
    public final static ItemStack AIR = new ItemStack(Material.AIR);
}
